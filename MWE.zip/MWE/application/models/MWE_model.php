<?php

class MWE_model extends CI_Model{
    
}

