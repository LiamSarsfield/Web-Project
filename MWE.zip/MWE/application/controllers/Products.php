<?php

class Products extends CI_Controller {
    

    public function scrapNotes() {
        
        $this->load->view('index');
        
    }
    
    public function materials() {
        
        $this->load->view('maintain_supplier');
        
    }

    public function details() {
        
        $this->load->view('maintain_supplier');
        
    }

    public function updateTraveller() {
        
        $this->load->view('maintain_supplier');
        
    }

    public function goodsNotes() {
        
        $this->load->view('maintain_supplier');
        
    }

    public function generateTraveller() {
        
        $this->load->view('maintain_supplier');
        
    }
}