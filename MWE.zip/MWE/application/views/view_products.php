<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Search Product</title>
<link rel="stylesheet" href="<?php echo base_url(); ?>/assests/CSS/style.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript"src="<?php echo base_url(); ?>/assests/script/navs.js"></script>
</head>

<body>
<!-- Icon Bar (Sidebar - hidden on small screens) -->
<nav class="w3-sidebar w3-bar-block w3-small w3-hide-small w3-center">
  <!-- Avatar image in top left corner -->
  <a href="<?php echo site_url()?>/Staff/staffLogin"><img src="<?php echo base_url(); ?>/assests/Images/MweLogo.png" style="width:100%"></a>
  
    <span style="font-size:30px;cursor:pointer" onclick="openNav()"  class="w3-bar-item  w3-button w3-padding-large w3-hover-black">&#9776;</span>
    <div id="mySidenav" class="sidenav">
        <button onclick="dropdown()" class="dropdown-btn w3-bar-item w3-button w3-padding-large w3-hover-black">
  <a href="<?php echo site_url()?>/Staff/staffLogin" class="w3-bar-item w3-button w3-hover-black" >
    <i class="
    fa fa-home w3-xxlarge"></i>
    <p>HOME</p>
  </a>
</button>

  <div  class="dropdown-container">
    <a href="#about" class="fa fa-user w3-bar-item w3-button w3-padding-large w3-hover-black"><p>ABOUT</p></a>
    <a href="#contact" class="fa fa-envelope w3-bar-item w3-button w3-padding-large w3-hover-black"><p>CONTACT</p></a>
    </div>
  
    <button onclick="dropdown()" class="dropdown-btn w3-bar-item w3-button w3-hover-black w3-bar-item w3-button w3-padding-large w3-hover-black">
    <i class="fa fa-drivers-license-o w3-xxlarge"></i>
    <p>CUSTOMERS</p>
</button>

<div  class="dropdown-container">
    <a href="<?php echo site_url()?>/Staff/viewCustomers" class="fa fa-edit w3-bar-item w3-button w3-padding-large w3-hover-black"><p>VIEW</p></a>
    <a href="<?php echo site_url()?>/Staff/viewInvoices" class="fa fa-edit w3-bar-item w3-button w3-padding-large w3-hover-black"><p>INVOICES</p></a>
    <a href="<?php echo site_url()?>/Staff/viewReturns" class="fa fa-exchange w3-bar-item w3-button w3-padding-large w3-hover-black"><p>RETURNS</p></a>
    <a href="<?php echo site_url()?>/Staff/viewOrders" class="fa fa-edit w3-bar-item w3-button w3-padding-large w3-hover-black"><p>ORDERS</p></a>
    </div>
  
    <button onclick="dropdown()" class="dropdown-btn w3-bar-item w3-button w3-hover-black w3-bar-item w3-button w3-padding-large w3-hover-black">
    <i class="fa fa-ship w3-xxlarge"></i>
    <p>SUPPLIER</p>
    </button>

    <div  class="dropdown-container">
    <a href="<?php echo site_url()?>/Supplier/maintain" class="fa fa-edit w3-bar-item w3-button w3-padding-large w3-hover-black"><p>MAINTAIN</p></a>
    <a href="<?php echo site_url()?>/Supplier/materialReq" class="fa fa-edit w3-bar-item w3-button w3-padding-large w3-hover-black"><p>MATERIAL REQ</p></a>
    <a href="<?php echo site_url()?>/Supplier/deliveries" class="fa fa-edit w3-bar-item w3-button w3-padding-large w3-hover-black"><p>DELIVERIES</p></a>
    <a href="<?php echo site_url()?>/Supplier/materialDetails" class="fa fa-edit w3-bar-item w3-button w3-padding-large w3-hover-black"><p>MATERIAL DETAILS</p></a>
    <a href="<?php echo site_url()?>/Supplier/orderReq" class="fa fa-edit w3-bar-item w3-button w3-padding-large w3-hover-black"><p>ORDER REQUESTS</p></a>
    <a href="<?php echo site_url()?>/Supplier/payment" class="fa fa-money w3-bar-item w3-button w3-padding-large w3-hover-black"><p>PAYMENT</p></a>
    </div>

    <button onclick="dropdown()" class="dropdown-btn w3-bar-item w3-button w3-hover-black w3-bar-item w3-button w3-padding-large w3-hover-black">
    <i class="fa fa-sitemap w3-xxlarge"></i>
    <p>PRODUCT</p>
    </button>

    <div  class="dropdown-container">
    <a href="<?php echo site_url()?>/Product/scrapNotes" class="fa fa-edit w3-bar-item w3-button w3-padding-large w3-hover-black"><p>SCRAP NOTES</p></a>
    <a href="<?php echo site_url()?>/Product/materials" class="fa fa-edit w3-bar-item w3-button w3-padding-large w3-hover-black"><p>RAW MATERIALS</p></a>
    <a href="<?php echo site_url()?>/Product/details" class="fa fa-edit w3-bar-item w3-button w3-padding-large w3-hover-black"><p>DETAILS</p></a>
    <a href="<?php echo site_url()?>/Product/updateTraveller" class="fa fa-edit w3-bar-item w3-button w3-padding-large w3-hover-black"><p>UPDATE TRAVELLER</p></a>
    <a href="<?php echo site_url()?>/Product/goodsNotes" class="fa fa-edit w3-bar-item w3-button w3-padding-large w3-hover-black"><p>GOODS NOTES</p></a>
    <a href="<?php echo site_url()?>/Product/generateTraveller" class="fa fa-edit w3-bar-item w3-button w3-padding-large w3-hover-black"><p>GENERATE TRAVELLER</p></a>
    </div>

    <a href="<?php echo site_url()?>/Home/Index" class="w3-bar-item w3-button w3-padding-large w3-hover-black">
            <i class="fa fa-rotate-left w3-xxlarge"></i>
            <p>Logout</p>
  </a>
</div>

</nav>


<!-- Navbar on small screens (Hidden on medium and large screens) -->
<div class="w3-top w3-hide-large w3-hide-medium" id="myNavbar">
  <div class="w3-bar w3-black w3-opacity w3-hover-opacity-off w3-center w3-small">
    <a href="#" class="w3-bar-item w3-button" style="width:25% !important">HOME</a>
    <a href="#about" class="w3-bar-item w3-button" style="width:25% !important">ABOUT</a>
  
    <a href="#contact" class="w3-bar-item w3-button" style="width:25% !important">CONTACT</a>
  </div>
</div>

<!-- Page Content -->
<div class="w3-padding-large" id="main">
  <!-- Header/Home -->
  <header class="w3-container w3-padding-32 w3-center w3-black" id="home">
        <img src="<?php echo base_url(); ?>/assests/Images/banner2.png" alt="boy" class="w3-image" width="620" height="420">
   
    
  </header>
<main>
 <a href="<?php echo site_url()?>/Product/details"><div class="button">Back To Index</div></a>
  <form action="<?php echo site_url()?>/Product/prodInfo" class="search_product_id generic_search">
    <fieldset>
      <legend>Search Product ID</legend>
      <div class="flex_container">
        <input type="text" class="generic_item_search_input generic_input" placeholder="Product ID">
        <input type="image" src="<?php echo base_url(); ?>/assests/Images/search-image-icon.png" alt="Submit" class="generic_search_submit" />
      </div>
    </fieldset>
  </form>
  <table class="table_generic" style="width:80%; margin-left:10%;">
    <tbody>
      <tr>
        <th scope="col">Product ID</th>
        <th scope="col">Product Name</th>
        <th scope="col">Product Price (€)</th>
        <th scope="col">View</th>
      </tr>
      <tr>
        <td>1001</td>
        <td>MSX Titan</td>
        <td>2,400</td>
        <td><a href="<?php echo site_url()?>/Product/prodInfo"><div class="button">View</div></a></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </tbody>
  </table>
</main>
</body>
</html>
