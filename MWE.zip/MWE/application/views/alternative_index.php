<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>MWE</title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="page">
<header> 
<a href="index.html"><img src="images/logo.jpg" alt="logo" width="153" height="160" title="Home"/></a><img src="images/midwest.jpg" alt="" width="780" height="160" id="title"/><img src="images/memberlogin2.jpg" alt="login" width="120" height="150" id="crest"/>
  <nav>
    <ul>
      <li><a class="active" href="customersearch.html">Customer</a></li>
      <li><a href="maintain_supplier.html">Supplier</a></li>
      <li><a href="view_products.html">Production</a></li>
      </ul>
</nav>
 
</header>
<p>
 
 </p>
<div id="leftCol">
  
<h1>Maintain Customer</h1>
<br>
<p><a href="prepare_customer_invoice.html"><img src="images/custbox.jpg" width="300" height="300" alt="" class="box"/></a></p>
</div>
<div id="rightCol">
   <div id="legend">
<h1>Maintain Supplier</h1>

   </div>

<br>
<p><a href="maintain_supplier.html"><img src="images/supbox.jpg" width="300" height="300" alt="" class="box"/></a></p>

</div>
<div id="col3">
   <div id="legend">
<h1>Maintain Production</h1>


   </div>

<br>
<p><a href="prepare_production_materials.html"><img src="images/prodbox.jpg" width="300" height="300" alt="" class="box"/></a></p>

</div>
<footer>
  <p>Copyright © 2018 Website by Dream Team </p>
</footer>
</div>

</body>
</html>
